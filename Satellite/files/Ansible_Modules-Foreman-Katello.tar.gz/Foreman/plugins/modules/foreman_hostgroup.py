#!/usr/bin/python
# -*- coding: utf-8 -*-
# (c) 2019 Manisha Singhal (ATIX AG)
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Ansible.  If not, see <http://www.gnu.org/licenses/>.

from __future__ import absolute_import, division, print_function
__metaclass__ = type


ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

DOCUMENTATION = '''
---
module: foreman_hostgroup
short_description: Manage Foreman Hostgroups using Foreman API
description:
  - Create, Update and Delete Foreman Hostgroups using Foreman API
author:
  - "Manisha Singhal (@Manisha15) ATIX AG"
  - "Baptiste Agasse (@bagasse)"
options:
  name:
    description: Name of hostgroup
    required: true
    type: str
  updated_name:
    description: New name of hostgroup. When this parameter is set, the module will not be idempotent.
    type: str
  description:
    description: Description of hostgroup
    required: false
    type: str
  parent:
    description: Hostgroup parent name
    required: false
    type: str
  realm:
    description: Realm name
    required: false
    type: str
  architecture:
    description: Architecture name
    required: False
    type: str
  medium:
    aliases: [ media ]
    description: Medium name
    required: False
    type: str
  operatingsystem:
    description: Operatingsystem title
    required: False
    type: str
  pxe_loader:
    description: PXE Bootloader
    required: false
    choices:
      - PXELinux BIOS
      - PXELinux UEFI
      - Grub UEFI
      - Grub2 BIOS
      - Grub2 ELF
      - Grub2 UEFI
      - Grub2 UEFI SecureBoot
      - Grub2 UEFI HTTP
      - Grub2 UEFI HTTPS
      - Grub2 UEFI HTTPS SecureBoot
      - iPXE Embedded
      - iPXE UEFI HTTP
      - iPXE Chain BIOS
      - iPXE Chain UEFI
    type: str
  ptable:
    description: Partition table name
    required: False
    type: str
  root_pass:
    description: root password
    required: false
    type: str
  environment:
    description: Puppet environment name
    required: false
    type: str
  puppetclasses:
    description: List of puppet classes to include in this host group. Must exist for hostgroup's puppet environment.
    required: false
    type: list
  config_groups:
    description: Config groups list
    required: false
    type: list
  puppet_proxy:
    description: Puppet server proxy name
    required: false
    type: str
  puppet_ca_proxy:
    description: Puppet CA proxy name
    required: false
    type: str
  openscap_proxy:
    description: OpenSCAP proxy name. Only available when the OpenSCAP plugin is installed.
    required: false
    type: str
  organization:
    description:
      - Organization for scoped resources attached to the hostgroup. Only used for katello installations.
      - This organization will implicitly be added to the I(organizations) parameter if needed.
    required: false
    type: str
  content_source:
    description: Katello Content source. Only available for katello installations.
    required: false
    type: str
  lifecycle_environment:
    description: Katello Lifecycle environment. Only available for katello installations.
    required: false
    type: str
  kickstart_repository:
    description: Kickstart repository name. Only available for katello installations.
    required: false
    type: str
  content_view:
    description: Katello Content view. Only available for katello installations.
    required: false
    type: str
  parameters:
    description:
      - Hostgroup specific host parameters
extends_documentation_fragment:
  - theforeman.foreman.foreman
  - theforeman.foreman.foreman.entity_state
  - theforeman.foreman.foreman.taxonomy
  - theforeman.foreman.foreman.nested_parameters
  - theforeman.foreman.foreman.host_options
'''

EXAMPLES = '''
- name: "Create a Hostgroup"
  foreman_hostgroup:
    name: "new_hostgroup"
    architecture: "architecture_name"
    operatingsystem: "operatingsystem_name"
    medium: "media_name"
    ptable: "Partition_table_name"
    server_url: "https://foreman.example.com"
    username: "admin"
    password: "secret"
    state: present

- name: "Update a Hostgroup"
  foreman_hostgroup:
    name: "new_hostgroup"
    architecture: "updated_architecture_name"
    operatingsystem: "updated_operatingsystem_name"
    organizations:
      - Org One
      - Org Two
    locations:
      - Loc One
      - Loc Two
      - Loc One/Nested loc
    medium: "updated_media_name"
    ptable: "updated_Partition_table_name"
    root_pass: "password"
    server_url: "https://foreman.example.com"
    username: "admin"
    password: "secret"
    state: present

- name: "My nested hostgroup"
  foreman_hostgroup:
    parent: "new_hostgroup"
    name: "my nested hostgroup"

- name: "My hostgroup with some proxies"
  foreman_hostgroup:
    name: "my hostgroup"
    environment: production
    puppet_proxy: puppet-proxy.example.com
    puppet_ca_proxy: puppet-proxy.example.com
    openscap_proxy: openscap-proxy.example.com

- name: "My katello related hostgroup"
  foreman_hostgroup:
    organization: "My Org"
    name: "kt hostgroup"
    content_source: capsule.example.com
    lifecycle_environment: "Production"
    content_view: "My content view"
    parameters:
      - name: "kt_activation_keys"
        value: "my_prod_ak"

- name: "Delete a Hostgroup"
  foreman_hostgroup:
    name: "new_hostgroup"
    server_url: "https://foreman.example.com"
    username: "admin"
    password: "secret"
    state: absent
'''

RETURN = ''' # '''

from ansible_collections.theforeman.foreman.plugins.module_utils.foreman_helper import (
    build_fqn,
    HostMixin,
    ForemanTaxonomicEntityAnsibleModule,
    OrganizationMixin,
    parameter_entity_spec,
    split_fqn,
)


class ForemanHostgroupAnsibleModule(OrganizationMixin, HostMixin, ForemanTaxonomicEntityAnsibleModule):
    pass


def main():
    module = ForemanHostgroupAnsibleModule(
        entity_spec=dict(
            name=dict(required=True),
            description=dict(),
            parent=dict(type='entity', flat_name='parent_id'),
            realm=dict(type='entity', flat_name='realm_id'),
            architecture=dict(type='entity', flat_name='architecture_id'),
            operatingsystem=dict(type='entity', flat_name='operatingsystem_id'),
            medium=dict(aliases=['media'], type='entity', flat_name='medium_id'),
            ptable=dict(type='entity', flat_name='ptable_id'),
            pxe_loader=dict(choices=['PXELinux BIOS', 'PXELinux UEFI', 'Grub UEFI', 'Grub2 BIOS', 'Grub2 ELF',
                                     'Grub2 UEFI', 'Grub2 UEFI SecureBoot', 'Grub2 UEFI HTTP', 'Grub2 UEFI HTTPS',
                                     'Grub2 UEFI HTTPS SecureBoot', 'iPXE Embedded', 'iPXE UEFI HTTP', 'iPXE Chain BIOS', 'iPXE Chain UEFI']),
            root_pass=dict(no_log=True),
            environment=dict(type='entity', flat_name='environment_id'),
            puppetclasses=dict(type='entity_list', flat_name='puppetclass_ids'),
            config_groups=dict(type='entity_list', flat_name='config_group_ids'),
            puppet_proxy=dict(type='entity', flat_name='puppet_proxy_id'),
            puppet_ca_proxy=dict(type='entity', flat_name='puppet_ca_proxy_id'),
            openscap_proxy=dict(type='entity', flat_name='openscap_proxy_id'),
            parameters=dict(type='nested_list', entity_spec=parameter_entity_spec),
            content_source=dict(type='entity', flat_name='content_source_id'),
            lifecycle_environment=dict(type='entity', flat_name='lifecycle_environment_id'),
            kickstart_repository=dict(type='entity', flat_name='kickstart_repository_id'),
            content_view=dict(type='entity', flat_name='content_view_id'),
        ),
        argument_spec=dict(
            organization=dict(),
            updated_name=dict(),
        ),
    )

    entity_dict = module.clean_params()

    module.connect()

    # Get short name and parent from provided name
    name, parent = split_fqn(entity_dict['name'])
    entity_dict['name'] = name

    katello_params = ['content_source', 'lifecycle_environment', 'content_view']

    if 'organization' not in entity_dict and list(set(katello_params) & set(entity_dict.keys())):
        module.fail_json(msg="Please specify the organization when using katello parameters.")

    if 'parent' in entity_dict:
        if parent:
            module.fail_json(msg="Please specify the parent either separately, or as part of the title.")
        parent = entity_dict['parent']
    if parent:
        entity_dict['parent'] = module.find_resource_by_title('hostgroups', title=parent, thin=True, failsafe=module.desired_absent)

        if module.desired_absent and entity_dict['parent'] is None:
            # Parent hostgroup does not exist so just exit here
            module.exit_json()

    if not module.desired_absent:
        if 'realm' in entity_dict:
            entity_dict['realm'] = module.find_resource_by_name('realms', name=entity_dict['realm'], failsafe=False, thin=True)

        if 'architecture' in entity_dict:
            entity_dict['architecture'] = module.find_resource_by_name('architectures', name=entity_dict['architecture'], failsafe=False, thin=True)

        if 'operatingsystem' in entity_dict:
            entity_dict['operatingsystem'] = module.find_operatingsystem(entity_dict['operatingsystem'], thin=True)

        if 'medium' in entity_dict:
            entity_dict['medium'] = module.find_resource_by_name('media', name=entity_dict['medium'], failsafe=False, thin=True)

        if 'ptable' in entity_dict:
            entity_dict['ptable'] = module.find_resource_by_name('ptables', name=entity_dict['ptable'], failsafe=False, thin=True)

        if 'environment' in entity_dict:
            entity_dict['environment'] = module.find_resource_by_name('environments', name=entity_dict['environment'], failsafe=False, thin=True)

        if 'config_groups' in entity_dict:
            entity_dict['config_groups'] = module.find_resources_by_name('config_groups', entity_dict['config_groups'], failsafe=False, thin=True)

        for proxy in ['puppet_proxy', 'puppet_ca_proxy', 'openscap_proxy', 'content_source']:
            if proxy in entity_dict:
                entity_dict[proxy] = module.find_resource_by_name('smart_proxies', entity_dict[proxy], thin=True)

        if 'organization' in entity_dict:
            if 'organizations' in entity_dict:
                if entity_dict['organization'] not in entity_dict['organizations']:
                    entity_dict['organizations'].append(entity_dict['organization'])
            else:
                entity_dict['organizations'] = [entity_dict['organization']]

            entity_dict, scope = module.handle_organization_param(entity_dict)

        if 'lifecycle_environment' in entity_dict:
            entity_dict['lifecycle_environment'] = module.find_resource_by_name('lifecycle_environments', name=entity_dict['lifecycle_environment'],
                                                                                params=scope, failsafe=False, thin=True)

        if 'kickstart_repository' in entity_dict:
            entity_dict['kickstart_repository'] = module.find_resource_by_name('repositories', name=entity_dict['kickstart_repository'],
                                                                               params=scope, failsafe=False, thin=True)

        if 'content_view' in entity_dict:
            entity_dict['content_view'] = module.find_resource_by_name('content_views', name=entity_dict['content_view'],
                                                                       params=scope, failsafe=False, thin=True)

    entity_dict = module.handle_common_host_params(entity_dict)
    entity_dict = module.handle_taxonomy_params(entity_dict)

    entity = module.find_resource_by_title('hostgroups', title=build_fqn(name, parent), failsafe=True)
    if entity:
        entity['root_pass'] = None
        if 'updated_name' in entity_dict:
            entity_dict['name'] = entity_dict.pop('updated_name')

    parameters = entity_dict.get('parameters')

    puppetclasses = entity_dict.pop('puppetclasses', None)
    current_puppetclasses = entity.pop('puppetclasses', None) if entity else []

    hostgroup = module.ensure_entity('hostgroups', entity_dict, entity)

    if hostgroup:
        scope = {'hostgroup_id': hostgroup['id']}
        module.ensure_scoped_parameters(scope, entity, parameters)

    if not module.desired_absent and 'environment_id' in hostgroup:
        if puppetclasses is not None:
            current_puppetclasses = [p['id'] for p in current_puppetclasses]
            for puppet_class_name in puppetclasses:
                scope = {'environment_id': hostgroup['environment_id']}

                # puppet classes API return puppet classes grouped by puppet module name
                puppet_modules = module.list_resource("puppetclasses", params=scope, search='name="{0}"'.format(puppet_class_name))

                # verify that only one puppet module is returned with only one puppet class inside
                # as provided search results have to be like "results": { "ntp": [{"id": 1, "name": "ntp" ...}]}
                # and get the puppet class id
                if len(puppet_modules) == 1 and len(list(puppet_modules.values())[0]) == 1:
                    puppet_classes = list(puppet_modules.values())[0]
                    puppet_class_id = puppet_classes[0]['id']
                    if puppet_class_id in current_puppetclasses:
                        current_puppetclasses.remove(puppet_class_id)
                    else:
                        payload = {'hostgroup_id': hostgroup['id'], 'puppetclass_id': puppet_class_id}
                        module.ensure_entity('hostgroup_classes', {}, None, params=payload, state='present', entity_spec={})
                else:
                    module.fail_json(msg='No data found for name="%s"' % puppet_class_name)
            if len(current_puppetclasses) > 0:
                for leftover_puppetclass in current_puppetclasses:
                    module.ensure_entity('hostgroup_classes', {}, {'id': leftover_puppetclass}, {'hostgroup_id': hostgroup['id']}, 'absent', entity_spec={})

    module.exit_json()


if __name__ == '__main__':
    main()
